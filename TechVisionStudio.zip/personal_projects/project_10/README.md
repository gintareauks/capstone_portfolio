# interactive-form-v3
Techdegree Full Stack JS Project 3

// REAL TIME VALIDATION 
Credit card forms that are neccessary to fill in have real time validation. These include:
- Credit card number => Displays an error message when less than 13 or more than 16 digits are entered. Valid sign displayed when the Card number is valid. 
- Zip code => Error message when less than or more than 5 digits are entered. Valid sign displayed when Zip code is valid.
- CVV => Error message when less than or more than 3 digits entered. Valid sign displayed when CVV is valid.

// CONDITIONAL ERROR MESSAGE
Email field has 2 conditional error messages that switch depending on the situation.
- "Email address must be formatted correctly"
- "Email field cannot be blank"
