baguetteBox.run('.gallery');
const search = new Filter('search', 'data-caption');